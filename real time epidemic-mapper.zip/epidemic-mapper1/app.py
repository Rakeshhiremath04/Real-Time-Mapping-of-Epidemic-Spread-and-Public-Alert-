# app.py (patched - submitted_reports simplified)
import os
import threading
import time
import random
import pickle
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import pandas as pd
import folium
import matplotlib.pyplot as plt
from twilio.rest import Client
from dotenv import load_dotenv
from flask_socketio import SocketIO, emit
import datetime
import smtplib
from email.mime.text import MIMEText

# ------------------- Setup -------------------
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", "devsecret")
socketio = SocketIO(app, cors_allowed_origins="*")  # WebSocket for real-time

@app.context_processor
def inject_current_year():
    return {"current_year": datetime.datetime.now().year}

DATA_FILE = "epidemic_data.csv"
MODEL_DIR = "model"
ALERT_THRESHOLD = int(os.getenv("ALERT_THRESHOLD", "1000000"))  # demo default


# ------------------- Data -------------------
if not os.path.exists(DATA_FILE):
    # create a tiny sample dataset so the app runs for demo
    sample = [
        {"state":"StateA","lat":21.0,"lon":78.0,"cases":100},
        {"state":"StateB","lat":19.0,"lon":77.0,"cases":200},
        {"state":"StateC","lat":22.0,"lon":79.0,"cases":50},
    ]
    pd.DataFrame(sample).to_csv(DATA_FILE, index=False)

df_lock = threading.Lock()
df = pd.read_csv(DATA_FILE)

# ------------------- Load ML Model -------------------
vectorizer, clf = None, None
try:
    with open(os.path.join(MODEL_DIR, "vectorizer.pkl"), "rb") as f:
        vectorizer = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "model.pkl"), "rb") as f:
        clf = pickle.load(f)
    print(" ML model loaded")
except FileNotFoundError:
    print("No trained model found. Run train_model.py first")
except Exception as e:
    print("Error loading model:", e)

# ------------------- Alerts -------------------
# SMTP / Email config
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))

ALERT_RECIPIENTS = os.getenv("ALERT_RECIPIENTS", "").split(",")
def send_email_alerts(state, cases):
    """
    Sends alert emails to ALERT_RECIPIENTS using a single SMTP connection.
    Creates a fresh MIMEText for each recipient and logs per-recipient errors.
    """
    if not (EMAIL_ADDRESS and EMAIL_PASSWORD):
        print("SMTP creds missing; skipping email alerts")
        return
    if not ALERT_RECIPIENTS:
        print("No alert recipients configured; skipping email alerts")
        return

    subject = f" ALERT: {state} reached {cases} cases"
    body = (
        f"ALERT!\n\n"
        f"State: {state}\n"
        f"Current Case Count: {cases}\n"
        f"Threshold: {ALERT_THRESHOLD}\n\n"
        f"Please take necessary precautions.\n\n"
        f"- Automated Epidemic Monitor"
    )

    try:
        # open connection once and reuse for all recipients
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=20) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

            for recipient in ALERT_RECIPIENTS:
                recipient = recipient.strip()
                if not recipient:
                    continue
                try:
                    msg = MIMEText(body)
                    msg["Subject"] = subject
                    msg["From"] = EMAIL_ADDRESS
                    msg["To"] = recipient
                    smtp.send_message(msg)
                    print(f"[EMAIL] Sent alert to {recipient}")
                except smtplib.SMTPException as e:
                    print(f"[EMAIL ERROR] Failed to send to {recipient}: {e}")
                except Exception as e:
                    print(f"[EMAIL ERROR] Unexpected error sending to {recipient}: {e}")

    except Exception as e:
        print(f"[EMAIL ERROR] Could not open SMTP connection: {e}")

# (Optional) placeholder for Twilio SMS function if you want SMS later
def send_sms_alerts(state, cases):
    if not (TWILIO_SID and TWILIO_AUTH and TWILIO_FROM):
        print("Twilio creds missing; skipping SMS")
        return
    if not ALERT_RECIPIENTS:
        print("No alert recipients configured; skipping SMS")
        return
    try:
        client = Client(TWILIO_SID, TWILIO_AUTH)
        body = f"ALERT: {state} has reached {cases} cases!"
        for to in ALERT_RECIPIENTS:
            to = to.strip()
            if not to:
                continue
            try:
                msg = client.messages.create(body=body, from_=TWILIO_FROM, to=to)
                print(f"[SMS] Sent to {to} sid={getattr(msg,'sid', 'n/a')}")
            except Exception as e:
                print("SMS error:", e)
    except Exception as e:
        print("SMS setup error:", e)

# ------------------- Real-time Simulation -------------------
def simulate_updates(interval=10):
    global df
    while True:
        time.sleep(interval)
        with df_lock:
            i = random.randint(0, len(df) - 1)
            inc = random.randint(100, 5000)
            df.at[i, "cases"] = int(df.at[i, "cases"]) + inc
            state = df.at[i, "state"]
            cases = df.at[i, "cases"]
            lat = float(df.at[i, "lat"])
            lon = float(df.at[i, "lon"])
            print(f"[SIM] +{inc} -> {state} = {cases}")

            # Emit update (include lat/lon)
            socketio.emit('update', {'state': state, 'cases': cases, 'lat': lat, 'lon': lon})

            # Send alerts (use email alerts; call in a separate thread if you expect blocking)
            if cases >= ALERT_THRESHOLD:
                # start email sending in a background thread so simulator loop doesn't block
                try:
                    threading.Thread(target=send_email_alerts, args=(state, cases), daemon=True).start()
                except Exception as e:
                    print("Failed to start email alert thread:", e)
                socketio.emit('alert', {'state': state, 'cases': cases, 'lat': lat, 'lon': lon})

t = threading.Thread(target=simulate_updates, daemon=True)
t.start()

# ------------------- Routes -------------------
@app.route("/")
def index():
    return render_template("index.html", df=df, clf=clf, ALERT_THRESHOLD=ALERT_THRESHOLD)

@app.route("/api/data")
def api_data():
    with df_lock:
        return jsonify(df.to_dict(orient="records"))

@app.route("/map")
def map_page():
    with df_lock:
        local_df = df.copy()

    m = folium.Map(location=[22.9734, 78.6569], zoom_start=5)
    for _, r in local_df.iterrows():
        try:
            cases = int(r["cases"])
        except:
            cases = 0
        radius = max(5, min((cases ** 0.5) * 0.15, 40))
        folium.CircleMarker(
            location=[r["lat"], r["lon"]],
            radius=radius,
            popup=f"{r['state']}: {cases} cases",
            color="red" if cases > ALERT_THRESHOLD / 10 else "orange",
            fill=True,
            fill_opacity=0.7
        ).add_to(m)

    # Save as standalone HTML in static/maps/
    maps_dir = os.path.join("static", "maps")
    os.makedirs(maps_dir, exist_ok=True)
    map_file = os.path.join(maps_dir, "map.html")
    try:
        m.save(map_file)
    except Exception as e:
        print("Error saving map file:", e)
        map_html = m.get_root().render()
        return render_template("map.html", map_html=map_html)

    return render_template("map.html", iframe_src=url_for('static', filename='maps/map.html'))

@app.route("/report", methods=["GET", "POST"])
def report():
    # Handles the report form. POST saves the report and redirects to thank-you page.
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        location = request.form.get("location", "").strip()
        symptoms = request.form.get("symptoms", "").strip()
        cases_input = request.form.get("cases", "").strip()

        try:
            cases_val = int(cases_input) if cases_input else None
        except Exception:
            cases_val = None

        predicted = None
        if vectorizer and clf and symptoms:
            try:
                X = vectorizer.transform([symptoms])
                predicted = clf.predict(X)[0]
            except Exception:
                predicted = None

        # Save report to CSV
        rep_line = {"name": name, "location": location, "symptoms": symptoms, "predicted": predicted}
        rep_df = pd.DataFrame([rep_line])
        if not os.path.exists("reports.csv"):
            rep_df.to_csv("reports.csv", index=False)
        else:
            rep_df.to_csv("reports.csv", mode="a", header=False, index=False)

        # Optionally update the main dataframe if user provided a cases number and location matches
        if cases_val and location:
            with df_lock:
                mask = df["state"].astype(str).str.lower() == location.lower()
                if mask.any():
                    idx = df[mask].index[0]
                    df.at[idx, "cases"] = cases_val
                    # emit update so clients get immediate change from manual report
                    try:
                        lat = float(df.at[idx, "lat"])
                        lon = float(df.at[idx, "lon"])
                        socketio.emit('update', {'state': df.at[idx, 'state'], 'cases': int(df.at[idx, 'cases']), 'lat': lat, 'lon': lon})
                    except Exception:
                        pass

        msg = f"Report submitted" if predicted else "Report submitted."
        return redirect(url_for("submitted_reports", msg=msg))

    # GET request -> render the report form
    return render_template("report.html")

@app.route("/submitted_reports")
def submitted_reports():
    # show a simple confirmation message after a report is submitted
    msg = request.args.get("msg", "Report submitted. Thank you.")
    return render_template("submitted_reports.html", msg=msg)

@app.route("/prediction")
def prediction():
    import numpy as np
    import textwrap

    graph_path = "static/prediction.png"

    try:
        # Aggregate and sort by current cases (descending)
        with df_lock:
            dfp = df.groupby("state", as_index=False)["cases"].sum()
        dfp = dfp.sort_values(by="cases", ascending=False).reset_index(drop=True)

        # Demo predicted values (replace with your model outputs when ready)
        rng = np.random.default_rng(seed=42)
        percents = 1 + rng.uniform(0.03, 0.15, size=len(dfp))
        dfp["predicted"] = (dfp["cases"] * percents).round().astype(int)

        # Shorten long state names for plot labels
        def short_label(s, n=24):
            s = str(s)
            return s if len(s) <= n else s[:n-1].rstrip() + "…"
        labels = [short_label(s) for s in dfp["state"].astype(str).tolist()]

        # Data arrays
        y = np.arange(len(labels))
        current = dfp["cases"].values
        predicted = dfp["predicted"].values

        # Figure size (wider for readability)
        height_inches = max(6, 0.35 * len(labels))
        fig_w = 14
        plt.figure(figsize=(fig_w, height_inches), dpi=110)
        ax = plt.gca()

        # Side-by-side bars
        bar_height = 0.35
        ax.barh(y - bar_height/2, current, height=bar_height, label="Current", color="#2f6f9f")
        ax.barh(y + bar_height/2, predicted, height=bar_height, label="Predicted", color="#ff8c2a", alpha=0.95)

        # Y-axis labels
        ax.set_yticks(y)
        ax.set_yticklabels(labels, fontsize=10)
        ax.invert_yaxis()  # largest on top

        # Axis labels and title
        ax.set_xlabel("Cases", fontsize=12)
        ax.set_title("Epidemic Prediction by State", fontsize=20, weight="bold", pad=12)

        # Grid + better readability
        ax.xaxis.grid(True, linestyle="--", linewidth=0.6, alpha=0.4)
        ax.set_axisbelow(True)

        # Compute x limits with margin so labels don't overflow
        max_val = max(current.max() if len(current) else 0, predicted.max() if len(predicted) else 0, 1)
        x_margin = max_val * 0.06  # 6% margin
        xmax = max_val + x_margin
        ax.set_xlim(0, xmax)

        # Helper: format with commas
        def fmt(n):
            return f"{int(n):,}"

        # Annotate predicted (on its bar) and current (on its bar).
        # Place inside bar if there's room; otherwise place outside but within axis.
        inside_frac = 0.10  # if value >= inside_frac * max_val -> put label inside (right-aligned)
        outside_offset = max_val * 0.01  # small offset when drawing outside

        for i, val in enumerate(predicted):
            label = fmt(val)
            ypos = i + bar_height/2
            # preferred x inside the bar (a bit away from right edge)
            inside_x = val - (xmax * 0.01)  # small padding from edge
            if val >= max_val * inside_frac and inside_x > 0:
                # ensure not too close to left edge
                x = min(inside_x, xmax - (xmax * 0.005))
                ax.text(x, ypos, label, ha="right", va="center",
                        fontsize=9, color="white", fontweight="bold")
            else:
                x = min(val + outside_offset, xmax - (xmax * 0.002))
                ax.text(x, ypos, label, ha="left", va="center",
                        fontsize=9, color="#333333",
                        bbox=dict(facecolor="white", edgecolor="none", pad=1, alpha=0.8))

        for i, val in enumerate(current):
            label = fmt(val)
            ypos = i - bar_height/2
            inside_x = val - (xmax * 0.01)
            if val >= max_val * inside_frac and inside_x > 0:
                x = min(inside_x, xmax - (xmax * 0.005))
                ax.text(x, ypos, label, ha="right", va="center",
                        fontsize=9, color="white", fontweight="bold")
            else:
                x = min(val + outside_offset, xmax - (xmax * 0.002))
                ax.text(x, ypos, label, ha="left", va="center",
                        fontsize=9, color="#333333",
                        bbox=dict(facecolor="white", edgecolor="none", pad=1, alpha=0.8))

        # Legend & tight layout
        ax.legend(frameon=True, fontsize=11, loc="upper right")
        plt.tight_layout()
        plt.savefig(graph_path, bbox_inches="tight")
        plt.close()

    except Exception as e:
        print("Prediction error:", e)
        return render_template("prediction.html", graph_file=graph_path)

    return render_template("prediction.html", graph_file=graph_path)

if __name__ == "__main__":
    socketio.run(app, debug=True)
