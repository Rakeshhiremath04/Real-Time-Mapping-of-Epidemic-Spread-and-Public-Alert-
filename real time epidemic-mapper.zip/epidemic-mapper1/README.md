# Real-Time Mapping of Epidemic Spread & Public Alert (demo)

## Setup (Windows / Linux / macOS)

1. Create a Python virtual env and activate it:
   ```bash
   python -m venv env
   # Windows
   .\env\Scripts\activate
   # Linux/macOS
   source env/bin/activate
