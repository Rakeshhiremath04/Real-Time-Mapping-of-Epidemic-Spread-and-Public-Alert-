# train_model.py
import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Small example dataset - replace with larger labeled dataset for production
symptoms = [
    "fever cough loss of smell difficulty breathing",
    "fever cough sore throat",
    "rash itchy blisters",
    "vomiting stomach pain diarrhea",
    "high fever joint pain severe headache",
    "runny nose sore throat mild fever"
]
diseases = [
    "COVID-19",
    "COVID-19",
    "Chickenpox",
    "Food Poisoning",
    "Dengue",
    "Flu"
]

os.makedirs("model", exist_ok=True)

vect = TfidfVectorizer()
X = vect.fit_transform(symptoms)

clf = MultinomialNB()
clf.fit(X, diseases)

with open("model/vectorizer.pkl", "wb") as f:
    pickle.dump(vect, f)
with open("model/model.pkl", "wb") as f:
    pickle.dump(clf, f)

print("✅ Trained model saved to model/model.pkl and model/vectorizer.pkl")
