import pandas as pd
from prophet import Prophet
import plotly.express as px
from datetime import datetime

# Load dataset
df = pd.read_csv(r"C:\Users\rakes\OneDrive\Desktop\epidemic-mapper1\prediction_input.csv")
df.columns = ['ds', 'y']

# Train model
model = Prophet()
model.fit(df)

# Create future dates (from today instead of last dataset date)
future_start = datetime.today().strftime("%Y-%m-%d")
future = model.make_future_dataframe(periods=10)
future['ds'] = pd.date_range(start=future_start, periods=len(future), freq='D')

# Predict
forecast = model.predict(future)

# Slice only future predictions
future_only = forecast[forecast['ds'] >= future_start]

# Plot
fig = px.line(future_only, x='ds', y='yhat', title='📈 Predicted Cases (From Today)')
fig.write_html("templates/prediction.html")
print("Forecast from today saved to templates/prediction.html")





