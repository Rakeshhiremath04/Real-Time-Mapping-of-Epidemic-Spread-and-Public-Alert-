import os
from twilio.rest import Client
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Read values from .env
TWILIO_SID = os.getenv("TWILIO_SID")
TWILIO_AUTH = os.getenv("TWILIO_AUTH")
TWILIO_FROM = os.getenv("TWILIO_FROM")  # Your Twilio phone number
TO = os.getenv("ALERT_RECIPIENT")       # Your personal phone number

# Initialize Twilio client
client = Client(TWILIO_SID, TWILIO_AUTH)

# Send SMS
message = client.messages.create(
    body="✅ Test alert: Your epidemic system SMS is working!",
    from_=TWILIO_FROM,
    to=TO
)

print("Message SID:", message.sid)
