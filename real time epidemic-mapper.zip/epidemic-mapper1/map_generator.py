import pandas as pd
import folium

df = pd.read_csv(r"C:\Users\rakes\OneDrive\Desktop\epidemic-mapper1\epidemic_data.csv")
latest = df.groupby('state').last().reset_index()

india_map = folium.Map(location=[22.9734, 78.6569], zoom_start=5)

for _, row in latest.iterrows():
    folium.Marker(
        location=[row['lat'], row['lon']],
        popup=f"{row['state']}: {row['cases']} cases",
        icon=folium.Icon(color="red" if row['cases'] > 500 else "green")
    ).add_to(india_map)
# Save to static folder for Flask
india_map.save("templates/map.html")
print(" Map saved to templates/map.html")
