<script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/4.5.4/socket.io.min.js"></script>
<script>
    var socket = io();
    socket.on('update', function(data){
        console.log("Update received:", data);
        // Update map marker here
    });
</script>
<script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/4.5.4/socket.io.min.js"></script>
<script>
    var socket = io();
    socket.on('update', function(data){
        console.log("Update received:", data);
        // Update map marker here
    });
</script>
