// static/js/main.js (UI-safe: does not attempt Socket.IO or polling)
(function () {
  console.log("main.js loaded (UI-safe). Real-time updates are server-only.");

  // If you still want to show a small message on the page, detect an element with id 'realtime-note'
  // and update it. This is optional — index.html above does not include live-updates.
  const note = document.getElementById('realtime-note');
  if (note) {
    note.textContent = "Real-time simulation running on server (terminal logs). UI updates are disabled.";
  }

  // No socket.io or polling is attempted here — prevents console errors when the client doesn't include socket.io.
})();
